TODO:
- plus/minus sign switching ==> DONE
- figure out why some replys aren't hiding ==> DONE
- probably make it so when you hide a comment it hides everything like how RES does
- probably refactor code, it looks kind of ugly